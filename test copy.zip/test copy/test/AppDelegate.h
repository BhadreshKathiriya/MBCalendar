//
//  AppDelegate.h
//  test
//
//  Created by Yogesh Patel on 23/05/16.
//  Copyright © 2016 lauruss. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@property (strong, nonatomic) UIWindow *window;


@end

