//
//  CKDemoViewController.h
//  MBCalendarKit
//
//  Created by Moshe Berman on 4/17/13.
//  Copyright (c) 2013 Moshe Berman. All rights reserved.
//

#import "CalendarKit.h"
#import "CKCalendarViewController.h"

@interface CKDemoViewController : CKCalendarViewController

@end
