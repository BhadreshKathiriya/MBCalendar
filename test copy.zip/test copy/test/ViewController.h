//
//  ViewController.h
//  test
//
//  Created by Yogesh Patel on 18/07/16.
//  Copyright © 2016 lauruss. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CKDemoViewController.h"

@interface ViewController : UIViewController
- (IBAction)btnClick:(id)sender;

@end
