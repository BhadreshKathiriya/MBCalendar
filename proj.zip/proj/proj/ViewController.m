//
//  ViewController.m
//  test
//
//  Created by Yogesh Patel on 18/07/16.
//  Copyright © 2016 lauruss. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray*date;
    NSArray*title;
    NSArray*img;
    NSArray*des;
    NSArray*evnt_ary;
    NSArray*timeary;
}



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    
    NSURLRequest *req=[[NSURLRequest alloc]initWithURL:[NSURL URLWithString:@"http://edutimeapp.com/toshow/chamber-of-commerc/ws/fetch_event.php"]];
    response =[[NSMutableData alloc]init];
    [NSURLConnection connectionWithRequest:req delegate:self];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [response appendData:data];
    NSLog(@"error receving data %@",response);
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error;
    
    NSLog(@"Error in receiving data %@",error);
    NSMutableDictionary *json = [NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableLeaves  error:&error];
    NSLog(@"response data %@",json);
    
    NSArray *results = [json objectForKey:@"status"];
    title = results;//[[results valueForKey:@"event"]valueForKey:@"event_title"];
    
    NSLog(@"event name fetch %@",title);
    
    
    date =[[results valueForKey:@"event"]valueForKey:@"event_date"];
 
    
    NSLog(@"event fetch %@",date);
    img =[[results valueForKey:@"event"]valueForKey:@"img"];
   
    des =[[results valueForKey:@"event"]valueForKey:@"event_detail"];
    evnt_ary =[[results valueForKey:@"event"]valueForKey:@"event_name"];
    timeary =[[results valueForKey:@"event"]valueForKey:@"event_time"];
}


- (IBAction)btnClick:(id)sender {
    CKDemoViewController *destVC = [[CKDemoViewController alloc] init];
    destVC.arr = title;
    [self presentViewController:destVC animated:YES completion:nil];
//    [self.navigationController pushViewController:[[CKDemoViewController alloc] init] animated:YES];
}
@end
